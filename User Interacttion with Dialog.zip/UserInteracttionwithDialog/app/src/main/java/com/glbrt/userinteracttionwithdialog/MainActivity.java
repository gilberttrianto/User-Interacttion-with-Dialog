package com.glbrt.userinteracttionwithdialog;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText etNama, etAlamat, etNomorTelepon, etEmail, etPassword;
    private RadioGroup rgJK;
    private Spinner spJurusan;
    private Button btnDaftar, btnDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNama = findViewById(R.id.et_nama);
        etAlamat =findViewById(R.id.et_alamat);
        etNomorTelepon = findViewById(R.id.et_notel);
        etEmail = findViewById(R.id.et_email);
        etPassword =  findViewById(R.id.et_password);

        rgJK = findViewById(R.id.rg_jk);
        spJurusan = findViewById(R.id.spin_jurusan);

        btnDaftar = findViewById(R.id.btn_daftar);
        btnDialog = findViewById(R.id.btn_dialog);

        btnDaftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = etNama.getText().toString();
                RadioButton selecRadioButton = findViewById(rgJK.getCheckedRadioButtonId());
                String jenisKelamin = selecRadioButton.getText().toString();
                String alamat = etAlamat.getText().toString();
                String nomorTelepon = etNomorTelepon.getText().toString();
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String jurusan = spJurusan.getSelectedItem().toString();

                boolean daftar = true;

                if (TextUtils.isEmpty(nama)) {
                    etNama.setError("Nama tidak boleh kosong!");
                    daftar = false;
                }
                if (TextUtils.isEmpty(alamat)) {
                    etAlamat.setError("Alamat tidak boleh kosong!");
                    daftar = false;
                }
                if (TextUtils.isEmpty(nomorTelepon)) {
                    etNomorTelepon.setError("Nomor telepon tidak boleh kosong!");
                    daftar = false;
                }
                if (TextUtils.isEmpty(email)) {
                    etEmail.setError("Email tidak boleh kosong!");
                    daftar = false;
                }
                if (TextUtils.isEmpty(password)) {
                    etPassword.setError("Password tidak boleh kosong!");
                    daftar = false;
                }

                if (daftar) {
                    Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                    intent.putExtra("NAMA", nama);
                    intent.putExtra("JENIS_KELAMIN", jenisKelamin);
                    intent.putExtra("ALAMAT", alamat);
                    intent.putExtra("NOMOR_TELEPON", nomorTelepon);
                    intent.putExtra("EMAIL", email);
                    intent.putExtra("JURUSAN", jurusan);
                    startActivity(intent);
                }
            }
        });

        btnDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder( MainActivity.this);
                builder.setTitle("Contoh Dialog");
                builder.setMessage("Ini adalah contoh dialog");
                builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "Anda menekan tombol Ya!",
                                Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
    }
}